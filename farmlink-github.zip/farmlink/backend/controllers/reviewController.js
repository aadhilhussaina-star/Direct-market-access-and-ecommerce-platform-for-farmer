const Review = require('../models/Review');
const Product = require('../models/Product');
const Order = require('../models/Order');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/products/:id/reviews
exports.list = asyncHandler(async (req, res) => {
  const reviews = await Review.find({ product: req.params.id }).populate('buyer', 'name').sort({ createdAt: -1 });
  res.json({ reviews });
});

// POST /api/products/:id/reviews   (only buyers who received this product)
exports.create = asyncHandler(async (req, res) => {
  const bought = await Order.exists({ buyer: req.user._id, status: 'Delivered', 'items.product': req.params.id });
  if (!bought) return res.status(403).json({ message: 'You can review a product only after it has been delivered to you' });

  const review = await Review.findOneAndUpdate(
    { product: req.params.id, buyer: req.user._id },
    { rating: req.body.rating, comment: req.body.comment },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );
  const [agg] = await Review.aggregate([
    { $match: { product: review.product } },
    { $group: { _id: '$product', avg: { $avg: '$rating' }, n: { $sum: 1 } } },
  ]);
  await Product.findByIdAndUpdate(req.params.id, { ratingAvg: Math.round(agg.avg * 10) / 10, ratingCount: agg.n });
  res.status(201).json({ review });
});
