const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const generateToken = require('../utils/generateToken');

const publicUser = (u) => ({
  id: u._id, name: u.name, email: u.email, phone: u.phone, role: u.role,
  address: u.address, village: u.village, isVerified: u.isVerified,
});

// POST /api/auth/register  (farmer or buyer only; admins are created by seed)
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, role, phone, address, village } = req.body;
  if (await User.findOne({ email: email.toLowerCase() })) {
    return res.status(409).json({ message: 'Email already registered' });
  }
  const user = await User.create({
    name, email, password, phone, address, village, role,
    isVerified: role === 'buyer', // buyers are active immediately, farmers wait for admin approval
  });
  res.status(201).json({ token: generateToken(user._id), user: publicUser(user) });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email.toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(req.body.password))) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  res.json({ token: generateToken(user._id), user: publicUser(user) });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => res.json({ user: publicUser(req.user) }));

// PUT /api/auth/me  (update own profile)
exports.updateMe = asyncHandler(async (req, res) => {
  ['name', 'phone', 'address', 'village'].forEach((k) => {
    if (req.body[k] !== undefined) req.user[k] = req.body[k];
  });
  await req.user.save();
  res.json({ user: publicUser(req.user) });
});
