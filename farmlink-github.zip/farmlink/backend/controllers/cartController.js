const Cart = require('../models/Cart');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/cart
exports.get = asyncHandler(async (req, res) => {
  const cart = await Cart.findOne({ buyer: req.user._id }).populate('items.product', 'name price unit stock images');
  res.json({ items: cart ? cart.items.filter((i) => i.product) : [] });
});

// PUT /api/cart   body: { items:[{product, qty}] }  (replaces the saved cart)
exports.save = asyncHandler(async (req, res) => {
  const cart = await Cart.findOneAndUpdate({ buyer: req.user._id }, { items: req.body.items }, { new: true, upsert: true })
    .populate('items.product', 'name price unit stock images');
  res.json({ items: cart.items });
});

// DELETE /api/cart
exports.clear = asyncHandler(async (req, res) => {
  await Cart.findOneAndUpdate({ buyer: req.user._id }, { items: [] });
  res.json({ message: 'Cart cleared' });
});
