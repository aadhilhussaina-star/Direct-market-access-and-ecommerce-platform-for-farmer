const Order = require('../models/Order');
const Product = require('../models/Product');
const Payment = require('../models/Payment');
const Cart = require('../models/Cart');
const asyncHandler = require('../utils/asyncHandler');
const sendEmail = require('../utils/email');

const FLOW = ['Placed', 'Packed', 'Shipped', 'Delivered'];

// POST /api/orders   body: { items:[{product, qty}], address, paymentMethod }
// Stock is decremented atomically per product (only if enough stock remains);
// if any line fails, the lines already reserved are rolled back.
exports.create = asyncHandler(async (req, res) => {
  const { items, address, paymentMethod = 'UPI' } = req.body;

  // merge duplicate lines
  const wanted = new Map();
  items.forEach((i) => wanted.set(String(i.product), (wanted.get(String(i.product)) || 0) + Number(i.qty)));

  const reserved = [];
  const lines = [];
  try {
    for (const [productId, qty] of wanted) {
      const p = await Product.findOneAndUpdate(
        { _id: productId, stock: { $gte: qty } },
        { $inc: { stock: -qty } },
        { new: true }
      );
      if (!p) {
        const exists = await Product.findById(productId).select('name stock');
        const err = new Error(exists ? `Only ${exists.stock} ${exists.name} left in stock` : 'A product in your order no longer exists');
        err.status = 409;
        throw err;
      }
      reserved.push({ productId, qty });
      lines.push({ product: p._id, farmer: p.farmer, name: p.name, price: p.price, qty });
    }
  } catch (err) {
    await Promise.all(reserved.map((r) => Product.updateOne({ _id: r.productId }, { $inc: { stock: r.qty } })));
    throw err;
  }

  const totalAmount = lines.reduce((s, l) => s + l.price * l.qty, 0); // price always comes from the DB
  const order = await Order.create({ buyer: req.user._id, items: lines, totalAmount, address, paymentMethod });
  await Payment.create({ order: order._id, method: paymentMethod, amount: totalAmount });
  await Cart.findOneAndUpdate({ buyer: req.user._id }, { items: [] });

  sendEmail(req.user.email, `FarmLink order #${order._id.toString().slice(-6).toUpperCase()} placed`,
    `Hi ${req.user.name}, your order of Rs.${totalAmount} has been placed.`);
  res.status(201).json({ order });
});

// GET /api/orders  (buyer: own, farmer: orders containing their produce, admin: all)
exports.list = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'buyer' ? { buyer: req.user._id }
    : req.user.role === 'farmer' ? { 'items.farmer': req.user._id } : {};
  if (req.query.status) filter.status = req.query.status;
  const orders = await Order.find(filter).populate('buyer', 'name phone').sort({ createdAt: -1 });
  res.json({ orders });
});

const canView = (order, user) =>
  user.role === 'admin' || String(order.buyer._id) === String(user._id) ||
  order.items.some((i) => i.farmer.equals(user._id));

// GET /api/orders/:id
exports.getOne = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('buyer', 'name phone email');
  if (!order) return res.status(404).json({ message: 'Order not found' });
  if (!canView(order, req.user)) return res.status(403).json({ message: 'Not allowed to view this order' });
  const payment = await Payment.findOne({ order: order._id });
  res.json({ order, payment });
});

// PUT /api/orders/:id/status   body: { status }  (farmer of that order, or admin; forward-only)
exports.updateStatus = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('buyer', 'name email');
  if (!order) return res.status(404).json({ message: 'Order not found' });
  const isFarmer = order.items.some((i) => i.farmer.equals(req.user._id));
  if (req.user.role !== 'admin' && !isFarmer) return res.status(403).json({ message: 'Not your order' });
  if (order.status === 'Cancelled') return res.status(400).json({ message: 'Order was cancelled' });

  const from = FLOW.indexOf(order.status), to = FLOW.indexOf(req.body.status);
  if (to !== from + 1) return res.status(400).json({ message: `Status must move from ${order.status} to ${FLOW[from + 1] || 'nothing (already delivered)'}` });

  order.status = req.body.status;
  if (order.status === 'Delivered' && order.paymentMethod === 'COD') {
    order.paymentStatus = 'Paid';
    await Payment.updateOne({ order: order._id }, { status: 'Paid', paidAt: new Date() });
  }
  await order.save();
  sendEmail(order.buyer.email, `Your FarmLink order is ${order.status}`, `Hi ${order.buyer.name}, your order status is now: ${order.status}.`);
  res.json({ order });
});

// PUT /api/orders/:id/cancel  (buyer, only while still 'Placed'); stock is returned
exports.cancel = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  if (!order.buyer.equals(req.user._id)) return res.status(403).json({ message: 'Not your order' });
  if (order.status !== 'Placed') return res.status(400).json({ message: 'Only orders that are still Placed can be cancelled' });
  order.status = 'Cancelled';
  await order.save();
  await Promise.all(order.items.map((i) => Product.updateOne({ _id: i.product }, { $inc: { stock: i.qty } })));
  res.json({ order });
});
