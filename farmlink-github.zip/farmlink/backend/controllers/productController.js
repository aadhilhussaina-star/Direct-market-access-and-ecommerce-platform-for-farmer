const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');
const { uploadImages } = require('../utils/cloudinary');

// GET /api/products?q=&category=&farmer=&minPrice=&maxPrice=&sort=&page=&limit=
exports.list = asyncHandler(async (req, res) => {
  const { q, category, farmer, minPrice, maxPrice, sort = 'newest', inStock } = req.query;
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 12));

  const filter = {};
  if (q) filter.$text = { $search: q };
  if (category && category !== 'All') filter.category = category;
  if (farmer) filter.farmer = farmer;
  if (inStock === 'true') filter.stock = { $gt: 0 };
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
  }

  const sorts = { newest: { createdAt: -1 }, 'price-asc': { price: 1 }, 'price-desc': { price: -1 }, name: { name: 1 }, rating: { ratingAvg: -1 } };
  const [products, total] = await Promise.all([
    Product.find(filter)
      .populate('farmer', 'name village isVerified')
      .sort(sorts[sort] || sorts.newest)
      .skip((page - 1) * limit)
      .limit(limit),
    Product.countDocuments(filter),
  ]);
  res.json({ products, page, pages: Math.ceil(total / limit), total });
});

// GET /api/products/:id
exports.getOne = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate('farmer', 'name village isVerified phone');
  if (!product) return res.status(404).json({ message: 'Product not found' });
  res.json({ product });
});

// POST /api/products  (verified farmer, multipart/form-data with optional images[])
exports.create = asyncHandler(async (req, res) => {
  if (req.user.role === 'farmer' && !req.user.isVerified) {
    return res.status(403).json({ message: 'Your farmer account is awaiting admin verification' });
  }
  const images = await uploadImages(req.files);
  const product = await Product.create({ ...req.body, images, farmer: req.user._id });
  res.status(201).json({ product });
});

const ownedProduct = async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) { res.status(404).json({ message: 'Product not found' }); return null; }
  if (req.user.role !== 'admin' && !product.farmer.equals(req.user._id)) {
    res.status(403).json({ message: 'You can only modify your own products' }); return null;
  }
  return product;
};

// PUT /api/products/:id  (update price / stock / details)
exports.update = asyncHandler(async (req, res) => {
  const product = await ownedProduct(req, res);
  if (!product) return;
  ['name', 'category', 'price', 'unit', 'stock', 'description'].forEach((k) => {
    if (req.body[k] !== undefined) product[k] = req.body[k];
  });
  const images = await uploadImages(req.files);
  if (images.length) product.images = images;
  await product.save();
  res.json({ product });
});

// DELETE /api/products/:id
exports.remove = asyncHandler(async (req, res) => {
  const product = await ownedProduct(req, res);
  if (!product) return;
  await product.deleteOne();
  res.json({ message: 'Product deleted' });
});
