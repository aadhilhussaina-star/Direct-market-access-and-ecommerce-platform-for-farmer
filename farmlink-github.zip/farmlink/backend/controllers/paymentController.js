const Order = require('../models/Order');
const Payment = require('../models/Payment');
const asyncHandler = require('../utils/asyncHandler');
const pay = require('../utils/payments');

const loadOwnOrder = async (req, res) => {
  const order = await Order.findById(req.body.orderId);
  if (!order) { res.status(404).json({ message: 'Order not found' }); return null; }
  if (!order.buyer.equals(req.user._id)) { res.status(403).json({ message: 'Not your order' }); return null; }
  if (order.paymentStatus === 'Paid') { res.status(400).json({ message: 'Order already paid' }); return null; }
  if (order.paymentMethod === 'COD') { res.status(400).json({ message: 'Cash on delivery orders are paid on delivery' }); return null; }
  return order;
};

// POST /api/payments/create-order   body: { orderId }
exports.createGatewayOrder = asyncHandler(async (req, res) => {
  const order = await loadOwnOrder(req, res);
  if (!order) return;

  let gatewayOrderId;
  if (pay.isLive()) {
    const g = await pay.client().orders.create({ amount: Math.round(order.totalAmount * 100), currency: 'INR', receipt: String(order._id) });
    gatewayOrderId = g.id;
  } else if (process.env.NODE_ENV === 'production') {
    return res.status(503).json({ message: 'Payment gateway is not configured' });
  } else {
    gatewayOrderId = `mock_order_${order._id}`; // development-only simulated gateway
  }
  await Payment.updateOne({ order: order._id }, { gatewayOrderId });
  res.json({ gatewayOrderId, amount: order.totalAmount, currency: 'INR', keyId: process.env.RAZORPAY_KEY_ID || null, mock: !pay.isLive() });
});

// POST /api/payments/verify   body: { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature }
exports.verify = asyncHandler(async (req, res) => {
  const order = await loadOwnOrder(req, res);
  if (!order) return;
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  const payment = await Payment.findOne({ order: order._id });
  if (!payment || payment.gatewayOrderId !== razorpay_order_id) return res.status(400).json({ message: 'Gateway order mismatch' });

  const ok = pay.isLive()
    ? pay.verifySignature(razorpay_order_id, razorpay_payment_id, razorpay_signature)
    : process.env.NODE_ENV !== 'production'; // simulated success in development

  if (!ok) {
    payment.status = 'Failed'; order.paymentStatus = 'Failed';
    await Promise.all([payment.save(), order.save()]);
    return res.status(400).json({ message: 'Payment verification failed' });
  }
  payment.status = 'Paid'; payment.transactionId = razorpay_payment_id || `mock_txn_${Date.now()}`; payment.paidAt = new Date();
  order.paymentStatus = 'Paid';
  await Promise.all([payment.save(), order.save()]);
  res.json({ message: 'Payment successful', order, payment });
});
