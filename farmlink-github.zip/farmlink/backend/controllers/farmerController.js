const mongoose = require('mongoose');
const Order = require('../models/Order');
const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/farmer/stats  -> products listed, orders, earnings (cancelled orders excluded)
exports.stats = asyncHandler(async (req, res) => {
  const farmerId = req.user._id;
  const [products, orders, earn] = await Promise.all([
    Product.countDocuments({ farmer: farmerId }),
    Order.countDocuments({ 'items.farmer': farmerId, status: { $ne: 'Cancelled' } }),
    Order.aggregate([
      { $match: { status: { $ne: 'Cancelled' }, 'items.farmer': new mongoose.Types.ObjectId(farmerId) } },
      { $unwind: '$items' },
      { $match: { 'items.farmer': new mongoose.Types.ObjectId(farmerId) } },
      { $group: { _id: null, total: { $sum: { $multiply: ['$items.price', '$items.qty'] } } } },
    ]),
  ]);
  res.json({ products, orders, earnings: earn[0]?.total || 0 });
});
