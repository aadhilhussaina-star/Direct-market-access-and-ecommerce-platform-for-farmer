const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const asyncHandler = require('../utils/asyncHandler');
const sendEmail = require('../utils/email');

// GET /api/admin/stats
exports.stats = asyncHandler(async (req, res) => {
  const [users, farmers, pendingFarmers, products, orders, sales] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ role: 'farmer' }),
    User.countDocuments({ role: 'farmer', isVerified: false }),
    Product.countDocuments(),
    Order.countDocuments(),
    Order.aggregate([{ $match: { status: { $ne: 'Cancelled' } } }, { $group: { _id: null, total: { $sum: '$totalAmount' } } }]),
  ]);
  res.json({ users, farmers, pendingFarmers, products, orders, salesVolume: sales[0]?.total || 0 });
});

// GET /api/admin/users?role=farmer&verified=false
exports.listUsers = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  if (req.query.verified) filter.isVerified = req.query.verified === 'true';
  res.json({ users: await User.find(filter).sort({ createdAt: -1 }) });
});

// PUT /api/admin/farmers/:id/verify   body: { verified: true|false }
exports.verifyFarmer = asyncHandler(async (req, res) => {
  const farmer = await User.findOne({ _id: req.params.id, role: 'farmer' });
  if (!farmer) return res.status(404).json({ message: 'Farmer not found' });
  farmer.isVerified = req.body.verified;
  await farmer.save();
  sendEmail(farmer.email, 'FarmLink account update',
    farmer.isVerified ? 'Your farmer account is verified. You can now list produce.' : 'Your farmer verification was revoked.');
  res.json({ user: farmer });
});

// DELETE /api/admin/users/:id
exports.deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  if (user.role === 'admin') return res.status(400).json({ message: 'Admin accounts cannot be deleted here' });
  if (user.role === 'farmer') await Product.deleteMany({ farmer: user._id });
  await user.deleteOne();
  res.json({ message: 'User removed' });
});
