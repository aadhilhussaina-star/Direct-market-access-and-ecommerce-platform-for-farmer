# FarmLink Backend

REST API for **Direct Market Access & E-Commerce Platform for Farmers** (MERN stack).
Node.js + Express + MongoDB (Mongoose), JWT auth, role-based access (farmer / buyer / admin).

## Quick start

```bash
npm install
cp .env.example .env        # then edit MONGO_URI and JWT_SECRET
npm run seed                # optional demo data
npm run dev                 # http://localhost:5000
```

Needs Node 18+ and a MongoDB (local or Atlas). Razorpay, Cloudinary and SMTP are all optional in development:
payments are simulated, image upload is skipped and emails are logged to the console until you add the keys.

Seeded accounts (password `password123`): `ramesh@farm.in`, `lakshmi@farm.in` (verified farmers), `murugan@farm.in` (unverified farmer), `anita@buy.in` (buyer), `admin@farm.in` (admin).

## Structure

```
config/db.js          MongoDB connection
models/               User, Product, Order, Payment, Review, Cart
middleware/           auth (protect, allowRoles), validate, upload (multer), error
controllers/          auth, product, order, payment, cart, review, farmer, admin
routes/               one router per resource
utils/                generateToken, email (Nodemailer), cloudinary, payments (Razorpay)
seed/seed.js          demo data  (npm run seed / npm run seed:destroy)
app.js  server.js     Express app / entry point
```

## API

Send `Authorization: Bearer <token>` for protected routes.

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | /api/auth/register | Public | Register farmer / buyer |
| POST | /api/auth/login | Public | Login, returns JWT |
| GET / PUT | /api/auth/me | Any | Own profile |
| GET | /api/products | Public | List: `q, category, farmer, minPrice, maxPrice, inStock, sort (newest\|price-asc\|price-desc\|name\|rating), page, limit` |
| GET | /api/products/:id | Public | Product detail |
| POST | /api/products | Verified farmer | Add product (multipart, optional `images`) |
| PUT | /api/products/:id | Owner farmer / admin | Update price, stock, details |
| DELETE | /api/products/:id | Owner farmer / admin | Delete product |
| GET / POST | /api/products/:id/reviews | Public / Buyer | Reviews (buyer must have a delivered order) |
| GET / PUT / DELETE | /api/cart | Buyer | Saved cart |
| POST | /api/orders | Buyer | Place order `{items:[{product,qty}], address, paymentMethod}` |
| GET | /api/orders | Any | Buyer: own, farmer: orders with their produce, admin: all |
| GET | /api/orders/:id | Participant / admin | Order + payment |
| PUT | /api/orders/:id/status | Farmer / admin | Placed → Packed → Shipped → Delivered |
| PUT | /api/orders/:id/cancel | Buyer | Cancel while still Placed (stock restored) |
| POST | /api/payments/create-order | Buyer | Create Razorpay order for an order |
| POST | /api/payments/verify | Buyer | Verify signature, mark Paid |
| GET | /api/farmer/stats | Farmer | Products, orders, earnings |
| GET | /api/admin/stats | Admin | Platform totals |
| GET | /api/admin/users | Admin | List users (`role`, `verified`) |
| PUT | /api/admin/farmers/:id/verify | Admin | Approve / revoke farmer |
| DELETE | /api/admin/users/:id | Admin | Remove user |
| GET | /api/health | Public | Health check |

## Design notes

- **Atomic stock:** orders decrement stock with `findOneAndUpdate({stock: {$gte: qty}})`, so two buyers can never oversell; failed orders roll back reserved stock.
- **Server-side prices:** order totals are computed from the database, never from the client.
- **Payments:** Razorpay order creation plus HMAC signature verification on the server. Without keys (development only) a simulated gateway is used; it is disabled when `NODE_ENV=production`.
- **Security:** bcrypt password hashes, JWT, role middleware, ownership checks, helmet, CORS allow-list, rate-limited auth routes, request validation.
- **Search speed:** text index on name/description, indexes on category and farmer, paginated lists.

## Connecting the frontend

Set `CLIENT_URL` to your React origin (comma-separated for several). Axios base URL: `http://localhost:5000/api`.
