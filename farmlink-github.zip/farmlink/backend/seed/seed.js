require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Payment = require('../models/Payment');
const Review = require('../models/Review');
const Cart = require('../models/Cart');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User, Product, Order, Payment, Review, Cart].map((m) => m.deleteMany({})));
  if (process.argv.includes('--destroy')) { console.log('All data removed'); return process.exit(0); }

  const pw = 'password123';
  const mk = (d) => User.create({ password: pw, ...d });
  const [ramesh, lakshmi, murugan, anita, admin] = await Promise.all([
    mk({ name: 'Ramesh Kumar', email: 'ramesh@farm.in', role: 'farmer', village: 'Thanjavur', phone: '9876500001', isVerified: true }),
    mk({ name: 'Lakshmi Devi', email: 'lakshmi@farm.in', role: 'farmer', village: 'Salem', phone: '9876500002', isVerified: true }),
    mk({ name: 'Murugan S', email: 'murugan@farm.in', role: 'farmer', village: 'Madurai', phone: '9876500003', isVerified: false }),
    mk({ name: 'Anita Sharma', email: 'anita@buy.in', role: 'buyer', address: '12, Gandhi Road, Chennai', isVerified: true }),
    mk({ name: 'Admin', email: 'admin@farm.in', role: 'admin', isVerified: true }),
  ]);

  const items = [
    ['Tomato', 'Vegetables', 40, 120, ramesh], ['Onion', 'Vegetables', 30, 85, ramesh], ['Mango', 'Fruits', 90, 40, ramesh], ['Rice (Ponni)', 'Grains', 55, 300, ramesh],
    ['Potato', 'Vegetables', 28, 200, lakshmi], ['Spinach', 'Vegetables', 25, 30, lakshmi], ['Banana', 'Fruits', 45, 60, lakshmi], ['Ragi', 'Grains', 60, 90, lakshmi], ['Groundnut', 'Grains', 110, 50, lakshmi],
  ];
  const products = await Product.insertMany(items.map(([name, category, price, stock, f]) => ({ name, category, price, stock, farmer: f._id, description: `Fresh ${name} straight from the farm.` })));

  const lineOf = (p, qty) => ({ product: p._id, farmer: p.farmer, name: p.name, price: p.price, qty });
  const specs = [[0, 10, 'Delivered'], [3, 25, 'Delivered'], [2, 8, 'Shipped'], [1, 15, 'Packed'], [4, 20, 'Placed']];
  for (const [idx, qty, status] of specs) {
    const p = products[idx];
    const total = p.price * qty;
    const o = await Order.create({ buyer: anita._id, items: [lineOf(p, qty)], totalAmount: total, status, address: anita.address, paymentMethod: 'UPI', paymentStatus: 'Paid' });
    await Payment.create({ order: o._id, method: 'UPI', amount: total, status: 'Paid', transactionId: `seed_txn_${o._id}`, paidAt: new Date() });
  }
  console.log('Seeded. Login password for all accounts: ' + pw);
  console.log('  farmer   ramesh@farm.in | lakshmi@farm.in | murugan@farm.in (unverified)');
  console.log('  buyer    anita@buy.in');
  console.log('  admin    admin@farm.in');
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
