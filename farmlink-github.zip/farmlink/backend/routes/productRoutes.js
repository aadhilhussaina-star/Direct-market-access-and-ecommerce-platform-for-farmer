const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/productController');
const reviews = require('../controllers/reviewController');
const { protect, allowRoles } = require('../middleware/auth');
const validate = require('../middleware/validate');
const upload = require('../middleware/upload');

const rules = [
  body('name').trim().notEmpty().withMessage('Product name is required'),
  body('category').isIn(['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Other']).withMessage('Invalid category'),
  body('price').isFloat({ min: 1 }).withMessage('Price must be at least 1'),
  body('stock').isInt({ min: 0 }).withMessage('Stock must be 0 or more'),
];

router.get('/', c.list);
router.get('/:id', c.getOne);
router.post('/', protect, allowRoles('farmer'), upload.array('images', 4), rules, validate, c.create);
router.put('/:id', protect, allowRoles('farmer', 'admin'), upload.array('images', 4), c.update);
router.delete('/:id', protect, allowRoles('farmer', 'admin'), c.remove);

router.get('/:id/reviews', reviews.list);
router.post('/:id/reviews', protect, allowRoles('buyer'), [
  body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be 1 to 5'),
], validate, reviews.create);

module.exports = router;
