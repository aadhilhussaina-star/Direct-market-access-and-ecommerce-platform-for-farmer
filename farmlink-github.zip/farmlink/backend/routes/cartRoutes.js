const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/cartController');
const { protect, allowRoles } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(protect, allowRoles('buyer'));
router.route('/').get(c.get).delete(c.clear).put([
  body('items').isArray().withMessage('items must be an array'),
  body('items.*.product').isMongoId().withMessage('Invalid product id'),
  body('items.*.qty').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
], validate, c.save);

module.exports = router;
