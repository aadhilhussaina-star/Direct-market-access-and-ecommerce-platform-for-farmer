const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/adminController');
const { protect, allowRoles } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(protect, allowRoles('admin'));
router.get('/stats', c.stats);
router.get('/users', c.listUsers);
router.put('/farmers/:id/verify', [body('verified').isBoolean().withMessage('verified must be true or false')], validate, c.verifyFarmer);
router.delete('/users/:id', c.deleteUser);

module.exports = router;
