const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/paymentController');
const { protect, allowRoles } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(protect, allowRoles('buyer'));
router.post('/create-order', [body('orderId').isMongoId().withMessage('Invalid order id')], validate, c.createGatewayOrder);
router.post('/verify', [
  body('orderId').isMongoId().withMessage('Invalid order id'),
  body('razorpay_order_id').notEmpty().withMessage('razorpay_order_id is required'),
], validate, c.verify);

module.exports = router;
