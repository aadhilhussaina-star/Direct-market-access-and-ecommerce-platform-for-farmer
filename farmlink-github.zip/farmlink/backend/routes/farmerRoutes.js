const router = require('express').Router();
const c = require('../controllers/farmerController');
const { protect, allowRoles } = require('../middleware/auth');

router.get('/stats', protect, allowRoles('farmer'), c.stats);

module.exports = router;
