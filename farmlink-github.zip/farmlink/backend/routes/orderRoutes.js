const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/orderController');
const { protect, allowRoles } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(protect);

router.post('/', allowRoles('buyer'), [
  body('items').isArray({ min: 1 }).withMessage('Order must contain at least one item'),
  body('items.*.product').isMongoId().withMessage('Invalid product id'),
  body('items.*.qty').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('address').trim().notEmpty().withMessage('Delivery address is required'),
  body('paymentMethod').optional().isIn(['UPI', 'Card', 'COD']).withMessage('Invalid payment method'),
], validate, c.create);

router.get('/', c.list);
router.get('/:id', c.getOne);
router.put('/:id/status', allowRoles('farmer', 'admin'), [
  body('status').isIn(['Packed', 'Shipped', 'Delivered']).withMessage('Status must be Packed, Shipped or Delivered'),
], validate, c.updateStatus);
router.put('/:id/cancel', allowRoles('buyer'), c.cancel);

module.exports = router;
