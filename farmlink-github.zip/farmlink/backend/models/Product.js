const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    farmer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: [true, 'Product name is required'], trim: true },
    category: { type: String, enum: ['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Other'], required: true, index: true },
    price: { type: Number, required: true, min: [1, 'Price must be at least 1'] },
    unit: { type: String, default: 'kg' },
    stock: { type: Number, required: true, min: [0, 'Stock cannot be negative'] },
    images: [{ type: String }],
    description: { type: String, trim: true },
    ratingAvg: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

productSchema.index({ name: 'text', description: 'text' }); // fast search

module.exports = mongoose.model('Product', productSchema);
