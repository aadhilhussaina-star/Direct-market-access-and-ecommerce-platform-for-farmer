const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    farmer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: String, // snapshot at time of purchase
    price: Number,
    qty: { type: Number, required: true, min: 1 },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    items: { type: [itemSchema], validate: (v) => v.length > 0 },
    totalAmount: { type: Number, required: true },
    status: { type: String, enum: ['Placed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'], default: 'Placed' },
    address: { type: String, required: true },
    paymentMethod: { type: String, enum: ['UPI', 'Card', 'COD'], default: 'UPI' },
    paymentStatus: { type: String, enum: ['Pending', 'Paid', 'Failed'], default: 'Pending' },
  },
  { timestamps: true }
);

orderSchema.index({ 'items.farmer': 1, createdAt: -1 });

module.exports = mongoose.model('Order', orderSchema);
