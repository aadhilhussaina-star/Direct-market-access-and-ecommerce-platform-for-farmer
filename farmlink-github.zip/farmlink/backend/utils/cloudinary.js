const cloudinary = require('cloudinary').v2;

const enabled = () => !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET);

// Uploads in-memory files to Cloudinary; returns [] when Cloudinary is not configured
exports.uploadImages = async (files = []) => {
  if (!enabled() || !files.length) return [];
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  return Promise.all(
    files.map(
      (f) =>
        new Promise((resolve, reject) => {
          cloudinary.uploader
            .upload_stream({ folder: 'farmlink/products' }, (err, result) => (err ? reject(err) : resolve(result.secure_url)))
            .end(f.buffer);
        })
    )
  );
};
