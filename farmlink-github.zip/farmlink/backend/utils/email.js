const nodemailer = require('nodemailer');

let transporter;
const getTransporter = () => {
  if (transporter !== undefined) return transporter;
  transporter = process.env.SMTP_HOST
    ? nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT) || 587,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      })
    : null;
  return transporter;
};

// Never throws: a failed email must not break an order
module.exports = async function sendEmail(to, subject, text) {
  if (!to) return;
  const t = getTransporter();
  if (!t) return console.log(`[email:disabled] to=${to} | ${subject}`);
  try {
    await t.sendMail({ from: process.env.MAIL_FROM || 'FarmLink <no-reply@farmlink.in>', to, subject, text });
  } catch (e) {
    console.error('Email failed:', e.message);
  }
};
