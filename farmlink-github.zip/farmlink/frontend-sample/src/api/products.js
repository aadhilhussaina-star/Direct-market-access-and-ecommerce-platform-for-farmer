import api from './axios';

// GET /products?q=&category=&sort=&page=
export const fetchProducts = (params) => api.get('/products', { params }).then((r) => r.data);

export const fetchProduct = (id) => api.get(`/products/${id}`).then((r) => r.data.product);

// Farmer: add a product (multipart so images can be attached)
export const createProduct = ({ images = [], ...fields }) => {
  const form = new FormData();
  Object.entries(fields).forEach(([k, v]) => form.append(k, v));
  images.forEach((file) => form.append('images', file));
  return api.post('/products', form).then((r) => r.data.product);
};

export const updateProduct = (id, changes) => api.put(`/products/${id}`, changes).then((r) => r.data.product);

export const deleteProduct = (id) => api.delete(`/products/${id}`);
