import api from './axios';

// items: [{ product: '<id>', qty: 2 }]
export const placeOrder = (items, address, paymentMethod = 'UPI') =>
  api.post('/orders', { items, address, paymentMethod }).then((r) => r.data.order);

export const fetchOrders = () => api.get('/orders').then((r) => r.data.orders);

// Farmer: move to the next status ('Packed' | 'Shipped' | 'Delivered')
export const updateOrderStatus = (id, status) => api.put(`/orders/${id}/status`, { status }).then((r) => r.data.order);

export const cancelOrder = (id) => api.put(`/orders/${id}/cancel`).then((r) => r.data.order);
