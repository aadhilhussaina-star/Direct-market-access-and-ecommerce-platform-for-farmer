# Frontend sample

Drop these files into a Vite + React project (`npm create vite@latest frontend -- --template react`), then:

```bash
npm install axios react-router-dom
cp .env.example .env
```

Wrap your app in `<AuthProvider>` and use `ProtectedRoute` for role-based pages.
