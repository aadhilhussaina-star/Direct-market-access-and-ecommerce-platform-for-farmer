# FarmLink: Direct Market Access & E-Commerce Platform for Farmers

A MERN-stack platform where farmers list produce at a price they set and buyers purchase directly from them, with no middlemen.

**Roles:** Farmer (manage products, stock, orders, earnings) · Buyer (search, cart, pay, track) · Admin (verify farmers, reports)

## Repository layout

| Folder | What it is |
|---|---|
| `backend/` | Node.js + Express + MongoDB REST API (JWT auth, role-based access, orders, Razorpay payments) |
| `frontend-sample/` | Starter React code: Axios client with JWT interceptor, auth context, product API helpers |
| `demo/` | Standalone browser demo of the UI (no server needed; data is saved in the browser) |

## Tech stack

MongoDB · Express.js · React · Node.js · Mongoose · JWT · bcrypt · Razorpay · Cloudinary · Nodemailer

## Run the backend

```bash
cd backend
npm install
cp .env.example .env     # set MONGO_URI and JWT_SECRET
npm run seed             # demo data (password for all accounts: password123)
npm run dev              # http://localhost:5000/api
```

Full endpoint list: see [`backend/README.md`](backend/README.md).

## Try the demo

Open `demo/index.html` in a browser, or enable **GitHub Pages** (Settings → Pages → Deploy from branch → `main` / root) and visit `/demo/`.
Demo logins (password `1234`): `ramesh@farm.in` (farmer), `anita@buy.in` (buyer), `admin@farm.in` (admin).

## Roadmap

- [x] Authentication & roles
- [x] Product, cart, order and payment APIs
- [x] Admin farmer verification
- [ ] Connect the React frontend to the API
- [ ] Notification module (in-app alerts)
- [ ] Automated tests and deployment (Render / Vercel + MongoDB Atlas)

## License

MIT
